package com.exemplo.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller responsável pelos endpoints da API
 * 
 * A anotação @RestController combina @Controller e @ResponseBody,
 * indicando que esta classe é um controller REST e que os métodos
 * retornam dados diretamente (não views)
 */
@RestController
@RequestMapping("/") // Mapeia este controller para a raiz da aplicação
public class MensagemController {

    /**
     * Endpoint GET /mensagem
     * Retorna uma mensagem simples confirmando que a API está funcionando
     * 
     * @return ResponseEntity com JSON contendo mensagem de sucesso
     */
    @GetMapping("/mensagem")
    public ResponseEntity<Map<String, Object>> getMensagem() {
        // Cria um mapa para estruturar a resposta JSON
        Map<String, Object> response = new HashMap<>();
        
        // Adiciona informações à resposta
        response.put("mensagem", "API funcionando corretamente");
        response.put("metodo", "GET");
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        response.put("status", "sucesso");
        
        // Retorna resposta com status HTTP 200 (OK)
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint POST /mensagem
     * Aceita dados via POST e retorna uma mensagem personalizada
     * 
     * @param requestBody Mapa contendo os dados enviados no corpo da requisição
     * @return ResponseEntity com JSON contendo mensagem personalizada
     */
    @PostMapping("/mensagem")
    public ResponseEntity<Map<String, Object>> postMensagem(@RequestBody(required = false) Map<String, Object> requestBody) {
        // Cria um mapa para estruturar a resposta JSON
        Map<String, Object> response = new HashMap<>();
        
        // Verifica se foram enviados dados no corpo da requisição
        String nomeUsuario = "Usuário";
        if (requestBody != null && requestBody.containsKey("nome")) {
            nomeUsuario = requestBody.get("nome").toString();
        }
        
        // Adiciona informações à resposta
        response.put("mensagem", "API funcionando corretamente via POST");
        response.put("saudacao", "Olá, " + nomeUsuario + "!");
        response.put("metodo", "POST");
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        response.put("status", "sucesso");
        response.put("dadosRecebidos", requestBody);
        
        // Retorna resposta com status HTTP 200 (OK)
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint GET /status
     * Endpoint adicional para verificar o status da API
     * 
     * @return ResponseEntity com informações de status da API
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getStatus() {
        Map<String, Object> response = new HashMap<>();
        
        response.put("api", "API Simples Spring Boot");
        response.put("versao", "1.0.0");
        response.put("status", "online");
        response.put("java_version", System.getProperty("java.version"));
        response.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        
        return ResponseEntity.ok(response);
    }
}

