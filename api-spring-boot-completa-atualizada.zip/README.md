# API Simples Spring Boot com Java 17

## Descrição

Esta é uma API simples desenvolvida com Spring Boot e Java 17, conforme as especificações solicitadas. A API inclui configuração de CORS específica para `http://localhost:3000` e uma interface frontend para validação da comunicação.

## Características Implementadas

### ✅ Linguagem e Framework
- **Java 17** (OpenJDK 17.0.15)
- **Spring Boot 3.2.0**
- **Maven** para gerenciamento de dependências

### ✅ Funcionalidade da API
A API possui os seguintes endpoints funcionais:

1. **GET /mensagem**
   - Retorna JSON com mensagem de confirmação
   - Resposta: `{"mensagem": "API funcionando corretamente", "metodo": "GET", "timestamp": "...", "status": "sucesso"}`

2. **POST /mensagem**
   - Aceita dados JSON no corpo da requisição
   - Retorna mensagem personalizada com os dados recebidos
   - Exemplo de envio: `{"nome": "João"}`
   - Resposta inclui saudação personalizada

3. **GET /status**
   - Retorna informações sobre a API
   - Inclui versão do Java, status da API e timestamp

### ✅ Configuração de CORS
- **Configuração específica** para `http://localhost:3000`
- **NÃO utiliza** `Access-Control-Allow-Origin: *`
- Implementada na classe `CorsConfig.java` com comentários explicativos
- Permite métodos: GET, POST, PUT, DELETE, OPTIONS
- Suporte a credenciais habilitado

### ✅ Comentários no Código
- Todos os arquivos possuem comentários detalhados
- Explicações sobre configuração de CORS
- Documentação dos endpoints e funcionalidades

### ✅ Interface Frontend
- **Página HTML responsiva** com JavaScript
- **Testes interativos** para todos os endpoints
- **Validação visual** da comunicação frontend-backend
- **Design moderno** com gradientes e animações
- **Indicador de status** da API em tempo real

## Estrutura do Projeto

```
api-simples/
├── src/
│   ├── main/
│   │   ├── java/com/exemplo/api/
│   │   │   ├── ApiSimplesApplication.java      # Classe principal
│   │   │   ├── config/
│   │   │   │   └── CorsConfig.java             # Configuração CORS
│   │   │   └── controller/
│   │   │       └── MensagemController.java     # Controller com endpoints
│   │   └── resources/
│   │       └── application.properties          # Configurações da aplicação
│   └── pom.xml                                 # Dependências Maven

frontend-api/
└── index.html                                  # Interface de teste
```

## Como Executar

### Pré-requisitos
- Java 17
- Maven 3.6+

### Executando a API

1. **Compilar o projeto:**
   ```bash
   cd api-simples
   mvn clean compile
   ```

2. **Executar a aplicação:**
   ```bash
   mvn spring-boot:run -Dmaven.test.skip=true
   ```

3. **A API estará disponível em:** `http://localhost:8080`

### Executando o Frontend

1. **Navegar para o diretório do frontend:**
   ```bash
   cd frontend-api
   ```

2. **Servir o frontend na porta 3000:**
   ```bash
   python3 -m http.server 3000
   ```

3. **Acessar no navegador:** `http://localhost:3000`

## Testando a API

### Via Frontend (Recomendado)
1. Acesse `http://localhost:3000`
2. Use os botões interativos para testar:
   - **Testar GET /mensagem**
   - **Testar GET /status**
   - **Testar POST /mensagem** (com campo de nome)

### Via cURL

**Teste GET /mensagem:**
```bash
curl -X GET http://localhost:8080/mensagem
```

**Teste POST /mensagem:**
```bash
curl -X POST http://localhost:8080/mensagem \
  -H "Content-Type: application/json" \
  -d '{"nome": "Teste"}'
```

**Teste GET /status:**
```bash
curl -X GET http://localhost:8080/status
```

## Validação do CORS

A configuração de CORS foi testada e validada:

1. ✅ **Frontend em `http://localhost:3000`** consegue acessar a API
2. ✅ **Requisições GET e POST** funcionam corretamente
3. ✅ **Não utiliza wildcard** (`*`) para origens
4. ✅ **Configuração específica** para o domínio solicitado

## Tecnologias Utilizadas

- **Backend:**
  - Java 17
  - Spring Boot 3.2.0
  - Spring Web
  - Maven

- **Frontend:**
  - HTML5
  - CSS3 (com gradientes e animações)
  - JavaScript (ES6+)
  - Fetch API para requisições

## Arquivos Principais

1. **ApiSimplesApplication.java** - Classe principal do Spring Boot
2. **CorsConfig.java** - Configuração detalhada de CORS
3. **MensagemController.java** - Controller com endpoints funcionais
4. **index.html** - Interface de teste frontend
5. **application.properties** - Configurações da aplicação

## Status dos Testes

✅ **API funcionando** - Todos os endpoints respondem corretamente  
✅ **CORS configurado** - Acesso permitido apenas para localhost:3000  
✅ **Frontend integrado** - Interface testa com sucesso a comunicação  
✅ **Java 17 confirmado** - Versão verificada no endpoint /status  
✅ **Comentários completos** - Código totalmente documentado

