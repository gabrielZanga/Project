package com.exemplo.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal da aplicação Spring Boot
 * 
 * A anotação @SpringBootApplication é uma anotação de conveniência que combina:
 * - @Configuration: Marca a classe como uma fonte de definições de beans
 * - @EnableAutoConfiguration: Habilita a configuração automática do Spring Boot
 * - @ComponentScan: Habilita o escaneamento de componentes no pacote atual e subpacotes
 */
@SpringBootApplication
public class ApiSimplesApplication {

    /**
     * Método principal que inicia a aplicação Spring Boot
     * 
     * @param args argumentos da linha de comando
     */
    public static void main(String[] args) {
        // Inicia a aplicação Spring Boot
        SpringApplication.run(ApiSimplesApplication.class, args);
        
        System.out.println("=================================");
        System.out.println("API Simples iniciada com sucesso!");
        System.out.println("Acesse: http://localhost:8080/mensagem");
        System.out.println("=================================");
    }
}

