package com.exemplo.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Classe de configuração para CORS (Cross-Origin Resource Sharing)
 * 
 * Esta configuração permite que a API seja acessada apenas pelo domínio específico
 * http://localhost:3000, seguindo as boas práticas de segurança ao não usar
 * Access-Control-Allow-Origin: *
 * 
 * A anotação @Configuration indica que esta classe contém definições de beans
 * e configurações para o Spring
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    /**
     * Configuração global de CORS para todos os endpoints da aplicação
     * 
     * Este método sobrescreve a configuração padrão do Spring MVC para CORS,
     * definindo especificamente quais origens, métodos e cabeçalhos são permitidos
     * 
     * @param registry Registro de configurações CORS
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry
            .addMapping("/**") // Aplica a configuração CORS para todos os endpoints (/**)
            .allowedOrigins("http://localhost:3000") // IMPORTANTE: Permite acesso APENAS do domínio específico
            .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Métodos HTTP permitidos
            .allowedHeaders("*") // Permite todos os cabeçalhos nas requisições
            .allowCredentials(true) // Permite envio de cookies e credenciais
            .maxAge(3600); // Cache do preflight por 1 hora (3600 segundos)
    }

    /**
     * Bean alternativo para configuração de CORS mais detalhada
     * 
     * Este bean fornece uma configuração mais granular de CORS que pode ser
     * usada em conjunto com filtros de segurança ou outras configurações avançadas
     * 
     * @return CorsConfigurationSource configurado
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        // Cria uma nova configuração CORS
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Define a origem permitida - APENAS http://localhost:3000
        // Não usamos "*" por questões de segurança
        configuration.addAllowedOrigin("http://localhost:3000");
        
        // Define os métodos HTTP permitidos
        configuration.addAllowedMethod("GET");
        configuration.addAllowedMethod("POST");
        configuration.addAllowedMethod("PUT");
        configuration.addAllowedMethod("DELETE");
        configuration.addAllowedMethod("OPTIONS");
        
        // Permite todos os cabeçalhos
        configuration.addAllowedHeader("*");
        
        // Permite credenciais (cookies, authorization headers, etc.)
        configuration.setAllowCredentials(true);
        
        // Define o tempo de cache para requisições preflight
        configuration.setMaxAge(3600L);
        
        // Registra a configuração para todos os caminhos
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        
        return source;
    }
}

